# src-persverscomp

Build pipeline for the Perseus Multitext Viewer. Unpack this zip's contents
directly into your existing `src-persverscomp/` directory -- it does not
touch `web/` or `work_registry.json`, both of which stay exactly as they are.

## What's in this zip

```
pipeline/            the build pipeline, split out of the old notebook
Makefile              make / make work=<key> / make force / make clean
manifest.json          new, empty -- gets populated on first build
tests/                  a handful of smoke tests (see "Testing" below)
notebooks/archive/       the original notebook, kept runnable
README.md (this file)
```

Not included (left as-is in your existing directory): `web/`,
`work_registry.json`, `lodcache/`, and anything under `WORKSPACE_DIR`
(`persverscomp/`) or `BUILD_DIR` (`/tmp/persvers_build`).

## Building

```
make                    # build every work whose sources changed since the last build
make work=tlg0085.tlg007  # build just one work
make force               # ignore manifest.json, rebuild everything
make clean                # delete the temp monolith
```

If the monolith at `/tmp/persvers_build/corpus_alignment_grid.db` is
missing (fresh clone, or after `make clean`), the next build reconstitutes
it from `site/data/**/*.db` first -- no TEI/treebank re-parsing needed --
then runs the normal manifest-driven pass on top of that.

## How this maps to the old notebook

Every cell's logic moved to a specific module; see the module docstrings
for exactly which cell it came from and what (if anything) changed in the
move. In short:

| Old cell | New home |
|---|---|
| Cell 0 (config) | `pipeline/config.py` |
| Cell 1 (WORK_REGISTRY) | `pipeline/registry.py` |
| Cell 4 (parsers + driver loop) | `pipeline/core/`, `pipeline/parsers/`, `pipeline/treebank/{conllu,agdt}.py`, `pipeline/ingest_work.py` |
| Cell 5 (treebank flatten) | `pipeline/treebank/flatten.py` |
| Cell 7 (place references) | `pipeline/places/topostext.py` |
| Cell 9 (sharding) | `pipeline/sharding.py` |
| Cell 10 (index.html builder) | `pipeline/index_builder.py` (WEB_SRC path fix -- see its docstring) |
| Cell 11 (shard loader JS) | not carried over as a Python generator -- see "What I deliberately didn't do" below |
| Cell 12 (lexicon parsers) | `pipeline/lexicon/parsers.py`, `pipeline/lexicon/ingest.py` |
| Cell 13 (lexicon sharding) | `pipeline/lexicon/shard.py` -- **not yet extracted, see below** |
| Cell 14 (treebank QA guard) | `pipeline/treebank/chunking_guard.py` |
| Cell 15 (cleanup) | `pipeline/cleanup.py` |
| *(new)* | `pipeline/manifest.py`, `pipeline/reconstitute.py`, `pipeline/build_all.py` |

The mechanical transform applied throughout Cell 4's driver tail (now
`ingest_work.py`) was: `for work_key, work_meta in WORK_REGISTRY.items():`
became `for work_key in target_keys: work_meta = WORK_REGISTRY[work_key]`.
Everything else in those loop bodies is unchanged from the notebook.

## What I deliberately didn't do

- **`pipeline/lexicon/shard.py` (Cell 13) was not extracted in this pass.**
  Everything else lexicon-related (`parsers.py`, `ingest.py`) is done; I ran
  out of turn budget before getting to the sharding step. It's a much
  smaller, more self-contained cell than Cell 4 or Cell 9 -- straightforward
  to pull over the same way the others were.
- **`sharding.py`'s `split_corpus_by_work` was moved verbatim, not made
  work-selective.** It still re-shards the entire monolith (and rebuilds
  `catalog.json`) on every call, even when `build_all.py` only just
  ingested one work. I didn't trace far enough into its ~400 lines to be
  confident a partial-shard filter wouldn't quietly break `catalog.json`'s
  cross-work aggregation, so `build_all.py` calls it unfiltered for now.
  Sharding a persistent monolith is still much cheaper than re-parsing TEI,
  so this is a real but bounded inefficiency, not a correctness risk.
- **Cell 11's `SHARD_LOADER_JS`** (a Python string constant that gets
  written out as `shard_loader.js`) wasn't ported into the package as-is.
  Since you asked not to touch `web/`, and the cleanest fix is to make
  `shard_loader.js` a real static file under `web/` rather than a generated
  string, I left this alone rather than either modifying `web/` or
  preserving an awkward string-constant generator. Worth a short follow-up
  once you're ready to touch `web/`.
- **No execution against real data.** I don't have your TEI/treebank
  source files or the real `work_registry.json` in this environment, so the
  four parser-dispatching phases in `ingest_work.py` (and the parser bodies
  themselves) have not run against real TEI. They compile cleanly and are
  mechanically relocated + parameterized, but treat your first real build as
  the actual test, and diff its output against a full rebuild from the
  archived notebook before trusting it.

  Everything else in the new orchestration layer HAS been run for real,
  against synthetic data, and this caught two actual bugs I've since fixed:
  - `build_all.py` never called `init_storage_engine` on a true first-ever
    run (no monolith AND no shards yet) -- it would have crashed with
    "no such table: text_units" the moment ingestion tried its first
    `DELETE FROM ... WHERE textgroup=?`. Fixed: that branch now explicitly
    initializes an empty schema.
  - `reconstitute.py`'s `DETACH DATABASE` was failing with "database is
    locked" because SQLite won't detach while a transaction is still open
    against the attached db. Fixed: commits before each detach.

  Also verified end-to-end against synthetic shards/rows: reconstituting a
  monolith from a shard (including the flatten-to-`treebank_tokens` step),
  and `_delete_existing_rows` -- the core piece that makes a single-work
  rebuild safe -- correctly scoping its deletes to one work only, including
  the `text_segments` subquery-based delete (it has no `textgroup`/`work`
  columns of its own, only `passage_urn`) without touching another work's
  rows.

## Testing

```
make test          # needs pytest: pip install pytest --break-system-packages
```

`tests/test_norm_key.py` and `tests/test_storage_table_classification.py`
both caught real bugs during this split (a bad test assumption about
sigma-folding, and an unclassified internal SQLite table) -- worth keeping
this pattern going as more parsers get fixture-driven tests.
