"""Lexicon TEI/TSV parsers (Cunliffe, Smith's Dict, Pizzi, Betant, Logeion).
Relocated from Cell 12.

norm_key here was a byte-for-byte duplicate of treebank/norm_key.py's copy
in the original notebook -- now both import the one copy.
"""
import re
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from pipeline.treebank.norm_key import norm_key

TEI_NS = "{http://www.tei-c.org/ns/1.0}"

XML_ID = "{http://www.w3.org/XML/1998/namespace}id"

XML_LANG = "{http://www.w3.org/XML/1998/namespace}lang"

def _tag(el):
    return el.tag.split('}')[-1]

def safe_parse_lexicon(path):
    """Same recover-on-error strategy as the main safe_parse(), redefined
    here so this cell doesn't depend on Cell 0 still being in memory."""
    try:
        import lxml.etree as LET
        parser = LET.XMLParser(recover=True)
        tree = LET.parse(str(path), parser=parser)
        import io
        buf = io.BytesIO()
        tree.write(buf)
        buf.seek(0)
        return ET.parse(buf)
    except ImportError:
        return ET.parse(str(path))

LEXICON_REGISTRY = {
    "cunliffe-words": {
        "path": "/Users/gcrane/github/Homerica/cunliffe.lexentries.unicode.xml",
        "format": "cunliffe",
        "title": "A Lexicon of the Homeric Dialect",
        "author": "Richard John Cunliffe",
        "citation": "Cunliffe, R. J. (1924). A Lexicon of the Homeric Dialect. Blackie and Son.",
        "entry_kind": "word",
        "textgroups": ["tlg0012"],           # Homer
        "shard_file": "lexica_homer.db",
    },
    "cunliffe-names": {
        "path": "/Users/gcrane/github/Homerica/cunliffe.hompers.unicode.xml",
        "format": "cunliffe",
        "title": "A Lexicon of the Homeric Dialect (Proper Names)",
        "author": "Richard John Cunliffe",
        "citation": "Cunliffe, R. J. (1924). A Lexicon of the Homeric Dialect. Blackie and Son.",
        "entry_kind": "name",
        "textgroups": ["tlg0012"],           # Homer
        "shard_file": "lexica_homer.db",     # same shard as cunliffe-words
    },
    "dindorf-aeschylus": {
        # UPDATE THIS to wherever the cleaned + translated file lands locally --
        # needs the version with the embedded-Greek markup pass and DeepSeek
        # translations applied (see Aeschylus_Lexicon_Translation.ipynb), not the
        # raw source. Filename convention from that notebook's own
        # _default_output_path: "<cleaned-file>.translated.xml".
        "path": "/Users/gcrane/github/GRC_misc/aeschylus-gemini.dindorf.lexicon.cleaned2.translated.xml",
        "format": "tei_dict",
        "title": "Lexicon Aeschyleum",
        "author": "Wilhelm Dindorf",
        "citation": "Dindorf, W. (1873\u20131876). Lexicon Aeschyleum. B. G. Teubner.",
        "entry_kind": "word",
        "textgroups": ["tlg0085"],           # Aeschylus
        "shard_file": "lexica_aeschylus.db",
    },
    "pizzi-persian": {
        "path": "/Users/gcrane/github/Shahnameh/pizzi-glossary.en.xml",
        "format": "pizzi",
        "title": "Manual of the Persian Language (Glossary)",
        "author": "Italo Pizzi",
        "citation": "Pizzi, I. (1891). Firdusiana anthology with a compendium of Persian "
                    "grammar and a dictionary. W. Gerhard.",
        "entry_kind": "word",
        "textgroups": ["ferdowsi"],           # matches WORK_REGISTRY["ferdowsi.shahnameh"]["textgroup"]
        "shard_file": "lexica_persian.db",
    },
    "betant-thucydides": {
        "path": "/Users/gcrane/github/Thucydides-new-working-materials/betant.thuclex_lateng5.xml",
        "format": "betant",
        "title": "Lexicon Thucydideum",
        "author": "\u00c9lie-Ami B\u00e9tant",
        "citation": "B\u00e9tant, \u00c9.-A. (1843\u20131847). Lexicon Thucydideum. Carey.",
        "entry_kind": "word",
        "textgroups": ["tlg0003"],           # Thucydides (no WORK_REGISTRY entry yet --
                                              # kept ready for when an edition is added)
        "shard_file": "lexica_thucydides.db",
    },
}

_LOGEION_LANG_CODES = {"grc", "lat"}

def _edition_lang_code(edition_id):
    """Scans every hyphen-separated segment (not just the trailing one --
    at least one real edition id embeds its language code mid-string,
    e.g. "segni-ita1-aligned") for a recognized language code, stripping
    trailing digits before matching.
    """
    for seg in edition_id.split("-"):
        code = seg.rstrip("0123456789").lower()
        if code in _LOGEION_LANG_CODES:
            return code
    return None

def _textgroups_with_language(lang_code):
    tgs = set()
    for work_key, meta in WORK_REGISTRY.items():
        tg = work_key.split(".")[0]
        if any(_edition_lang_code(ed_id) == lang_code for ed_id in meta.get("editions", {})):
            tgs.add(tg)
    return sorted(tgs)

def _lang_toggle_class(elem):
    """Returns ' tb-lex-lat' / ' tb-lex-eng' / '' based on xml:lang, for
    tags where the Hide-Latin toggle should apply. Deliberately ignores the
    'type' attribute (translation vs original) -- xml:lang alone is what
    both Betant's existing gloss pairs and Dindorf's Aeschylus-lexicon
    same-tag pairs (<def>/<def>, <note>/<note>, <quote>/<quote>,
    <foreign>/<foreign>) use to distinguish the two languages, so checking
    only xml:lang keeps this working for both formats without a
    format-specific branch here."""
    lang = elem.get(XML_LANG, '')
    if lang == 'lat':
        return ' tb-lex-lat'
    if lang == 'eng':
        return ' tb-lex-eng'
    return ''

def _lex_inline_html(elem, lexicon_id, entry_id_by_target=None):
    """Renders one lexicon entry element (and its children) to HTML.
    `entry_id_by_target` is unused here (cross-refs are resolved at click
    time in the browser, not at build time), kept as a parameter in case a
    future pass wants to grey out dead links whose target never got
    ingested.

    The lat/eng toggle-class logic (tb-lex-lat / tb-lex-eng, hidden/shown by
    the existing "Hide Latin" control) originally only applied to <gloss>,
    matching Betant's <gloss xml:lang="lat">/<gloss xml:lang="eng"> pairs.
    Dindorf's Aeschylus lexicon (added via the translation notebook) instead
    reuses each ORIGINAL tag name for its translation sibling -- <def>/<def>,
    <note>/<note>, <quote>/<quote>, <foreign>/<foreign>, <usg>/<usg> -- so
    def/note/quote/foreign/usg all now go through the same _lang_toggle_class
    helper <gloss> already used. The one Aeschylus-specific piece NOT handled
    here is the headword's own English gloss (<form><gloss xml:lang="eng">);
    that's pulled out separately in parse_lexicon_dict_tei and used as
    headword_translit instead of being rendered inline, the same way Pizzi's
    transliteration already works -- see that function below.
    """
    tag = _tag(elem)
    parts = []

    if tag == 'p':
        parts.append('<div class="tb-lex-p">')
    elif tag == 'sense':
        parts.append('<div class="tb-lex-sense">')
    elif tag == 'cit':
        parts.append('<div class="tb-lex-cit">')
    elif tag == 'def':
        parts.append(f'<span class="tb-lex-def{_lang_toggle_class(elem)}">')
    elif tag == 'note':
        parts.append(f'<span class="tb-lex-note{_lang_toggle_class(elem)}">(')
    elif tag == 'bibl':
        parts.append('<span class="tb-lex-cite">')
    elif tag == 'quote':
        # Betant's teiHeader notes the Greek citation text was never keyed in
        # for budget reasons -- <quote/> ships as an empty placeholder in
        # ~35k spots. Rendering an empty <div> for each would be pure clutter,
        # so bail out before the wrapper is even opened. (Dindorf's Aeschylus
        # lexicon has real quote text throughout, but the guard is harmless
        # and still worth keeping for the rare genuinely-empty case there too.)
        if not elem.text and len(elem) == 0:
            return ''
        lang = elem.get('{http://www.w3.org/XML/1998/namespace}lang', '')
        if lang == 'grc':
            cls = 'tb-lex-quote tb-greek'
        else:
            cls = f'tb-lex-quote{_lang_toggle_class(elem)}'
        parts.append(f'<div class="{cls}">')
    elif tag == 'foreign':
        lang = elem.get('{http://www.w3.org/XML/1998/namespace}lang', '')
        cls = 'tb-greek' if lang in ('greek', 'grc') else _lang_toggle_class(elem).strip()
        parts.append(f'<span class="{cls}">')
    elif tag == 'usg':
        # Not present in Betant's format -- new for Dindorf's Aeschylus
        # lexicon (usage-style notes, e.g. "κατ' ἄκρας"). Same lang-based styling
        # as foreign; falls through unstyled for the rare usg with no
        # recognized language (a handful of descriptive labels with no
        # xml:lang at all).
        lang = elem.get('{http://www.w3.org/XML/1998/namespace}lang', '')
        cls = 'tb-greek' if lang == 'grc' else _lang_toggle_class(elem).strip()
        if cls:
            parts.append(f'<span class="{cls}">')
    elif tag == 'term':
        parts.append('<span class="tb-lex-term">')
    elif tag == 'gloss':
        # Betant pairs a Latin definition with an added English translation as
        # two sibling <gloss> elements -- tag each with its xml:lang so the
        # reader-side "Hide Latin" toggle can target tb-lex-lat via CSS.
        lang = elem.get(XML_LANG, '')
        cls = 'tb-lex-gloss'
        if lang == 'lat':
            cls += ' tb-lex-lat'
        elif lang == 'eng':
            cls += ' tb-lex-eng'
        parts.append(f'<span class="{cls}">')
    elif tag == 'hi':
        parts.append('<span class="tb-lex-hi">')
    elif tag == 'ref':
        target = (elem.get('target') or '').strip()
        if target:
            parts.append(
                f'<a href="javascript:void(0)" class="tb-lex-ref" '
                f'onclick="openLexiconEntry(\'{lexicon_id}\',\'{target}\')">'
            )
        else:
            parts.append('<span class="tb-lex-ref-dead">')
    # head / form / orth are handled separately by the caller (they supply
    # the entry's own headword, shown once in the panel title) -- skip here
    # so the headword doesn't get duplicated inside the entry body.
    elif tag in ('head', 'form', 'orth'):
        return ''

    if elem.text:
        parts.append(elem.text)
    for child in elem:
        parts.append(_lex_inline_html(child, lexicon_id, entry_id_by_target))
        if child.tail:
            parts.append(child.tail)

    if tag == 'p':
        parts.append('</div>')
    elif tag == 'sense':
        parts.append('</div>')
    elif tag == 'cit':
        parts.append('</div>')
    elif tag == 'def':
        parts.append('</span>')
    elif tag == 'note':
        parts.append(')</span>')
    elif tag == 'bibl':
        parts.append('</span>')
    elif tag == 'quote':
        parts.append('</div>')
    elif tag == 'usg':
        lang = elem.get('{http://www.w3.org/XML/1998/namespace}lang', '')
        cls = 'tb-greek' if lang == 'grc' else _lang_toggle_class(elem).strip()
        if cls:
            parts.append('</span>')
    elif tag in ('foreign', 'term', 'gloss', 'hi'):
        parts.append('</span>')
    elif tag == 'ref':
        target = (elem.get('target') or '').strip()
        parts.append('</a>' if target else '</span>')

    return ''.join(parts)

def _plain_text_len(elem):
    """Rough visible-character count of an element's rendered content --
    used only to flag very short 'see X' pointer entries for aliasing."""
    return len(re.sub(r'<[^>]+>', '', _lex_inline_html(elem, '_probe_')))

def parse_lexicon_cunliffe_tei(path, lexicon_id):
    tree = safe_parse_lexicon(path)
    root = tree.getroot()
    body = root.find(f'.//{TEI_NS}body')
    if body is None:
        body = root.find('.//body')
    if body is None:
        print(f"  \u26a0 no <body> found in {path}")
        return [], [], []

    entries, aliases, citations = [], [], []

    for div in body:
        if _tag(div) != 'div':
            continue
        entry_id = div.get(XML_ID)
        if not entry_id:
            continue  # nested/unlabeled sub-divs are handled inside their parent, not iterated here
        headword_display = (div.get('n') or '').strip()
        if not headword_display:
            head_el = div.find(f'{TEI_NS}head')
            if head_el is None:
                head_el = div.find('head')
            headword_display = (''.join(head_el.itertext()).strip() if head_el is not None else entry_id)

        headword_key = norm_key(headword_display)

        # Render every child except <head> (already captured as the headword).
        body_html = ''.join(
            _lex_inline_html(child, lexicon_id)
            for child in div if _tag(child) != 'head'
        )

        entries.append({
            "entry_id": entry_id,
            "headword_display": headword_display,
            "headword_key": headword_key,
            "sort_key": headword_key or '',
            "entry_html": body_html,
        })

        # Short "see X" pointer entries: alias this headword straight to
        # the single ref's target so a lookup resolves to the fuller entry.
        refs = div.findall(f'.//{TEI_NS}ref') or div.findall('.//ref')
        if len(refs) == 1 and _plain_text_len(div) < 60:
            target = (refs[0].get('target') or '').strip()
            if target:
                aliases.append({"alias_key": headword_key, "entry_id": target})

        # Citations with real CTS URNs: <bibl n="Perseus:abo:tlg,0012,001:14:78">
        for bibl in div.findall(f'.//{TEI_NS}bibl') or div.findall('.//bibl'):
            n = (bibl.get('n') or '').strip()
            m = re.match(r'^Perseus:abo:tlg,(\d+),(\d+):(.+)$', n)
            if m:
                tg_num, wk_num, ref_parts = m.groups()
                citations.append({
                    "entry_id": entry_id,
                    "textgroup": f"tlg{tg_num}",
                    "work": f"tlg{wk_num}",
                    "ref": ref_parts.replace(':', '.'),
                    "urn": f"urn:cts:greekLit:tlg{tg_num}.tlg{wk_num}:{ref_parts.replace(':', '.')}",
                })

    return entries, aliases, citations

AESCHYLUS_PLAY_CANON = {
    "ag": "Ag", "agamemnon": "Ag",
    "ch": "Ch", "choephori": "Ch",
    "eum": "Eum", "eumenides": "Eum",
    "pers": "Pers", "persians": "Pers",
    "pr": "Pr", "prometheus": "Pr",
    "sept": "Sept", "septem": "Sept",
    "suppl": "Suppl", "supplices": "Suppl",
    "fr": "Fr",
}

AESCHYLUS_BIBL_RE = re.compile(r'^([A-Za-z]+)\.?\s+(?:\(fr\.\s*)?(\d+)\)?\.?$')

PLAY_NAME_TO_WORK = {
    # Fill in once the Aeschylus WORK_REGISTRY entries exist, e.g.:
    # "Ag": "tlg001", "Ch": "tlg002", ... (canonical keys from
    # AESCHYLUS_PLAY_CANON above, NOT the raw source-text spelling).
}

def _normalize_bibl_spacing(txt):
    # OCR sometimes inserts a space before the abbreviation's period,
    # e.g. "Ag . 1004" -- normalize before matching.
    return re.sub(r'\s+\.', '.', txt)

def parse_lexicon_dict_tei(path, lexicon_id):
    tree = safe_parse_lexicon(path)
    root = tree.getroot()
    edition_div = None
    for div in root.iter(f'{TEI_NS}div'):
        if div.get('type') == 'edition':
            edition_div = div
            break
    if edition_div is None:
        print(f"  \u26a0 no <div type=\"edition\"> found in {path}")
        return [], [], []

    entries, aliases, citations = [], [], []

    for entry in edition_div.findall(f'{TEI_NS}entry') or edition_div.findall('entry'):
        entry_id = entry.get(XML_ID)
        if not entry_id:
            continue

        orth_el = entry.find(f'.//{TEI_NS}orth')
        if orth_el is None:
            orth_el = entry.find('.//orth')
        headword_display = (''.join(orth_el.itertext()).strip() if orth_el is not None else entry_id)
        headword_key = norm_key(headword_display)

        # Headword's own English gloss, if the translation notebook has
        # been run for this entry: <form><orth>...</orth><gloss
        # xml:lang="eng" type="translation">...</gloss></form>. Shown next
        # to the Greek headword via the existing headword_translit
        # rendering (same one Pizzi's transliteration uses) -- NOT
        # rendered inline in the body (body_html already skips the whole
        # <form> below, so this doesn't need its own exclusion).
        headword_translit = None
        form_el = entry.find(f'{TEI_NS}form')
        if form_el is not None:
            gloss_el = form_el.find(f'{TEI_NS}gloss')
            if gloss_el is not None and gloss_el.get(XML_LANG) == 'eng':
                headword_translit = ''.join(gloss_el.itertext()).strip() or None

        body_html = ''.join(
            _lex_inline_html(child, lexicon_id)
            for child in entry if _tag(child) != 'form'
        )

        entries.append({
            "entry_id": entry_id,
            "headword_display": headword_display,
            "headword_translit": headword_translit,
            "headword_key": headword_key,
            "sort_key": headword_key or '',
            "entry_html": body_html,
        })

        for cit in entry.iter(f'{TEI_NS}cit'):
            bibl_el = cit.find(f'{TEI_NS}bibl')
            if bibl_el is None:
                bibl_el = cit.find('bibl')
            bibl_text = (''.join(bibl_el.itertext()).strip() if bibl_el is not None else '')
            if not bibl_text:
                continue
            norm = _normalize_bibl_spacing(bibl_text)
            m = AESCHYLUS_BIBL_RE.match(norm)
            if not m:
                continue  # multi-number ref, fragment sub-citation, or a
                          # citation of another author/lexicographer -- not
                          # an Aeschylus play/fragment line reference
            play_raw, line = m.groups()
            canon = AESCHYLUS_PLAY_CANON.get(play_raw.lower())
            if canon is None:
                continue  # matched the shape but isn't a recognized
                          # Aeschylus play (e.g. "Hesychius 123", "Pollux 45")
            work_id = PLAY_NAME_TO_WORK.get(canon)
            citations.append({
                "entry_id": entry_id,
                "textgroup": "tlg0085",  # always Aeschylus, independent of
                                         # whether the specific play's
                                         # work_id is filled in yet
                "work": work_id,
                "ref": line,
                "urn": (f"urn:cts:greekLit:tlg0085.{work_id}:{line}"
                        if work_id else None),
            })

    return entries, aliases, citations

def _pizzi_render_child(elem, lexicon_id, translit_index):
    """Like _lex_inline_html, but: (a) <div subtype="wsense"> gets a visible
    sense-number wrapper, (b) <ref> and the target of a 'see X' <term n="v">
    have no target attribute in the source -- they're resolved here by
    normalizing their text and looking it up in translit_index (built from
    every entry's headword_translit). A miss renders as plain/muted text
    instead of a broken link -- about a third of refs won't resolve (they
    point to inflected forms, not headwords), and that's fine."""
    tag = _tag(elem)
    parts = []

    if tag == 'div' and elem.get('subtype') == 'wsense':
        n = elem.get('n', '')
        parts.append(f'<div class="tb-lex-wsense"><span class="tb-lex-sense-num">{n}.</span> ')
    elif tag == 'p':
        parts.append('<div class="tb-lex-p">')
    elif tag == 'gloss':
        parts.append('<span class="tb-lex-gloss">')
    elif tag == 'term':
        n = elem.get('n', '')
        url = n.split(':', 1)[1] if ':' in n and n.split(':', 1)[1].startswith('http') else None
        parts.append(f'<a href="{url}" target="_blank" rel="noopener" class="tb-lex-term-link">' if url
                      else '<span class="tb-lex-term">')
    elif tag == 'foreign':
        lang = elem.get(XML_LANG, '')
        cls = 'tb-lex-fa tb-lex-hi' if lang.startswith('fas') else 'tb-lex-hi'
        parts.append(f'<span class="{cls}">')
    elif tag == 'ref':
        text = ''.join(elem.itertext()).strip()
        target = translit_index.get(norm_key(text))
        if target:
            parts.append(f'<a href="javascript:void(0)" class="tb-lex-ref" '
                         f'onclick="openLexiconEntry(\'{lexicon_id}\',\'{target}\')">')
        else:
            parts.append('<span class="tb-lex-ref-dead">')

    if elem.text:
        parts.append(elem.text)
    for child in elem:
        parts.append(_pizzi_render_child(child, lexicon_id, translit_index))
        if child.tail:
            parts.append(child.tail)

    if tag == 'div' and elem.get('subtype') == 'wsense':
        parts.append('</div>')
    elif tag == 'p':
        parts.append('</div>')
    elif tag == 'gloss':
        parts.append('</span>')
    elif tag == 'term':
        n = elem.get('n', '')
        url = n.split(':', 1)[1] if ':' in n and n.split(':', 1)[1].startswith('http') else None
        parts.append('</a>' if url else '</span>')
    elif tag == 'foreign':
        parts.append('</span>')
    elif tag == 'ref':
        text = ''.join(elem.itertext()).strip()
        target = translit_index.get(norm_key(text))
        parts.append('</a>' if target else '</span>')

    return ''.join(parts)

def parse_lexicon_pizzi_tei(path, lexicon_id):
    tree = safe_parse_lexicon(path)
    root = tree.getroot()
    body = root.find(f'.//{TEI_NS}body')
    if body is None:
        print(f"  \u26a0 no <body> found in {path}")
        return [], [], []

    raw_entries = []          # (entry_id, headword_display, headword_translit, children)
    translit_index = {}       # norm_key(translit) -> entry_id, first-wins on homographs

    for div in body:
        if _tag(div) != 'div' or div.get('subtype') != 'entry':
            continue
        entry_id = div.get(XML_ID)
        if not entry_id:
            continue

        heads = div.findall(f'{TEI_NS}head')
        script_head = next((h for h in heads if h.get(XML_LANG) == 'fas'), None)
        translit_head = next((h for h in heads if (h.get(XML_LANG) or '').startswith('fas-t')), None)
        headword_display = (''.join(script_head.itertext()).strip()
                             if script_head is not None else entry_id)
        headword_translit = (''.join(translit_head.itertext()).strip()
                              if translit_head is not None else None)

        children = [c for c in div if _tag(c) != 'head']
        raw_entries.append((entry_id, headword_display, headword_translit, children))

        tkey = norm_key(headword_translit)
        if tkey and tkey not in translit_index:  # first entry wins a homograph collision
            translit_index[tkey] = entry_id

    entries, aliases = [], []
    for entry_id, headword_display, headword_translit, children in raw_entries:
        # headword_key matches the SCRIPT form -- this is what has to line up
        # with the treebank's lemma column (Persian script, per the .fa.conllu
        # naming in WORK_REGISTRY["ferdowsi.shahnameh"]).
        headword_key = norm_key(headword_display)
        body_html = ''.join(_pizzi_render_child(c, lexicon_id, translit_index) for c in children)

        entries.append({
            "entry_id": entry_id,
            "headword_display": headword_display,
            "headword_translit": headword_translit,
            "headword_key": headword_key,
            "sort_key": norm_key(headword_translit) or headword_key or '',
            "entry_html": body_html,
        })

        # "see X" pointer entries: <term n="v">see</term> <foreign>TARGET</foreign>,
        # short enough that the whole entry is really just a cross-reference.
        plain_len = len(re.sub(r'<[^>]+>', '', body_html))
        if plain_len < 80:
            see_terms = [c for c in children if _tag(c) == 'p']
            for p in see_terms:
                kids = list(p)
                for i, k in enumerate(kids):
                    if _tag(k) == 'term' and k.get('n') == 'v' and i + 1 < len(kids) \
                            and _tag(kids[i + 1]) == 'foreign':
                        target_text = ''.join(kids[i + 1].itertext()).strip()
                        target_id = translit_index.get(norm_key(target_text))
                        if target_id:
                            aliases.append({"alias_key": headword_key, "entry_id": target_id})

    # Pizzi is a dictionary/grammar, not a citation-heavy commentary -- no
    # <bibl n="Perseus:..."> anywhere in the source, so citations stay empty
    # (same as Cunliffe's names lexicon). Nothing to parse here.
    citations = []
    return entries, aliases, citations

BETANT_BIBL_RE = re.compile(r'^(?:thuc\.|Thuc\.)\s*(\d+)\.(\d+)(?:\.(\d+))?$')

def parse_lexicon_betant_tei(path, lexicon_id):
    tree = safe_parse_lexicon(path)
    root = tree.getroot()
    body = root.find(f'.//{TEI_NS}body')
    if body is None:
        body = root.find('.//body')
    if body is None:
        print(f"  \u26a0 no <body> found in {path}")
        return [], [], []

    entries, aliases, citations = [], [], []
    auto_counter = 0
    seen_ids = {}  # base id -> occurrence count -- Betant's `n` (an LSJ beta-code
                   # id) is occasionally reused across 2+ entries (158 cases: e.g.
                   # an adjective and adverb, or two distinct senses, sharing one
                   # LSJ cross-reference), so it isn't unique on its own the way
                   # Cunliffe's xml:id is.

    # iter() rather than a direct child walk: entries sit one level down
    # inside <div type="textpart" subtype="section"> letter-groupings
    # (24 of them, e.g. alpha/beta/...), not directly under <body>.
    for entry_div in body.iter(f'{TEI_NS}div'):
        if entry_div.get('type') != 'textpart' or entry_div.get('subtype') != 'entry':
            continue

        n_attr = (entry_div.get('n') or '').strip()
        if n_attr:
            base_id = n_attr
        else:
            auto_counter += 1
            base_id = f"betant-auto-{auto_counter}"

        seen_ids[base_id] = seen_ids.get(base_id, 0) + 1
        entry_id = base_id if seen_ids[base_id] == 1 else f"{base_id}-{seen_ids[base_id]}"

        head_el = entry_div.find(f'{TEI_NS}head')
        if head_el is None:
            head_el = entry_div.find('head')
        headword_display = (''.join(head_el.itertext()).strip() if head_el is not None else entry_id)

        # The `n` attribute holds the lexicon's own canonical lemma
        # (prefixed "lsj-", e.g. "lsj-ἀβασάνιστος"), which is often the TRUE
        # dictionary headword even when <head> shows a different
        # inflected/derived form in THIS entry (e.g. head shows the
        # adverb "ἀβασανίστως" while n names the adjective
        # "ἀβασάνιστος" it's filed under). Prefer it for headword_key
        # (matched against treebank lemma_norm -- see norm_key's own
        # docstring) so entries like that are still found by the base
        # form's lemma, while headword_display keeps showing this
        # entry's own actual head text unchanged.
        LSJ_LEMMA_PREFIX = "lsj-"
        lemma_from_n = (n_attr[len(LSJ_LEMMA_PREFIX):].strip()
                        if n_attr.startswith(LSJ_LEMMA_PREFIX) else None)
        headword_key = norm_key(lemma_from_n) if lemma_from_n else norm_key(headword_display)

        body_html = ''.join(
            _lex_inline_html(child, lexicon_id)
            for child in entry_div if _tag(child) != 'head'
        )

        entries.append({
            "entry_id": entry_id,
            "headword_display": headword_display,
            "headword_key": headword_key,
            "sort_key": headword_key or '',
            "entry_html": body_html,
        })

        for bibl in entry_div.iter(f'{TEI_NS}bibl'):
            ref_attr = (bibl.get('n') or '').strip()
            m = BETANT_BIBL_RE.match(ref_attr)
            if not m:
                continue  # shouldn't happen -- every bibl in this source matched at ingest time
            book, chapter, section = m.groups()
            ref = f"{book}.{chapter}" + (f".{section}" if section else "")
            citations.append({
                "entry_id": entry_id,
                "textgroup": "tlg0003",
                "work": "tlg001",
                "ref": ref,
                "urn": f"urn:cts:greekLit:tlg0003.tlg001:{ref}",
            })

    return entries, aliases, citations

def parse_lexicon_logeion_tsv(path, lexicon_id):
    entries, aliases, citations = [], [], []
    seen_ids = {}
    skipped = 0
    with open(path, encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.rstrip("\n")
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) != 2:
                print(f"  ! {path}:{line_no}: expected 2 tab-separated fields, "
                      f"got {len(parts)} -- skipping")
                skipped += 1
                continue
            headword, definition = parts
            headword = headword.strip()
            definition = definition.strip()
            if not headword:
                skipped += 1
                continue

            base_id = headword
            seen_ids[base_id] = seen_ids.get(base_id, 0) + 1
            entry_id = base_id if seen_ids[base_id] == 1 else f"{base_id}-{seen_ids[base_id]}"

            headword_key = norm_key(headword)
            entry_html = (f'<div class="tb-lex-p"><span class="tb-lex-gloss">'
                          f'{html.escape(definition)}</span></div>')

            entries.append({
                "entry_id": entry_id,
                "headword_display": headword,
                "headword_key": headword_key,
                "sort_key": headword_key or '',
                "entry_html": entry_html,
            })
    if skipped:
        print(f"  ({skipped} lines skipped in {path})")
    return entries, aliases, citations

LEXICON_FORMAT_PARSERS = {
    "cunliffe": parse_lexicon_cunliffe_tei,
    "tei_dict": parse_lexicon_dict_tei,
    "pizzi": parse_lexicon_pizzi_tei,
    "betant": parse_lexicon_betant_tei,
    "logeion": parse_lexicon_logeion_tsv,
}

