"""doc_type -> parser function registry, so ingest_work.py and anything
else that dispatches on WORK_REGISTRY's doc_type field has one place to
look. NEW module -- didn't exist as such in the notebook (dispatch used to
be inlined in the Cell 4 driver loop via if/elif on doc_type).
"""
from pipeline.parsers.poetry_cards import parse_poetry_cards_tei
from pipeline.parsers.card_prose import parse_card_prose_tei
from pipeline.parsers.milestones import parse_milestone_tei
from pipeline.parsers.reading_lines import parse_reading_lines_tei
from pipeline.parsers.hierarchical import parse_hierarchical_tei
from pipeline.parsers.speech_collection import parse_speech_collection_tei
from pipeline.parsers.book_chapter_section import parse_book_chapter_section_tei
from pipeline.parsers.line_commentary import parse_line_commentary_tei

DOC_TYPE_PARSERS = {
    "poetry_cards": parse_poetry_cards_tei,
    "card_prose": parse_card_prose_tei,
    "milestone": parse_milestone_tei,
    "reading_lines": parse_reading_lines_tei,
    "hierarchical": parse_hierarchical_tei,
    "speech_collection": parse_speech_collection_tei,
    "book_chapter_section": parse_book_chapter_section_tei,
    "line_commentary": parse_line_commentary_tei,
}
