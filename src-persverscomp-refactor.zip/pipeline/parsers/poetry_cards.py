"""doc_type: poetry_cards. Relocated from Cell 4."""
from pipeline.core.xml_utils import NS, safe_parse, find_text_root, extract_text_recursive

def parse_poetry_cards_tei(path, master_intervals, lineno_sigil=None, line_remap=None):
    if not os.path.exists(path): return None
    tree = safe_parse(path)
    text_entry = find_text_root(tree.getroot())

    data = OrderedDict((bk, OrderedDict()) for bk in master_intervals)
    flat_intervals, card_n_to_label = [], {}
    for bk, ivs in master_intervals.items():
        for iv in ivs:
            flat_intervals.append(iv)
            card_n_to_label[(bk, iv["card_n"])] = iv["label"]

    # Poem-carded works (Propertius etc.) label cards with the bare poem
    # number/name itself ("2", "8a", ...), never a "start-end" line range --
    # only the milestone-carded builder ever produces a hyphenated label.
    # The line-number fallback below assumes line numbers are unique within
    # a book (true for Homer/Vergil's continuous numbering); for elegy, line
    # numbers reset every poem, so e.g. poem 2's own line 1 would spuriously
    # match poem 1's 1-38 interval (scanned first) and get merged into it.
    # Detect that shape once and disable the fallback entirely for it -- the
    # div subtype="poem" boundary check above is the sole source of truth.
    is_poem_carded = bool(flat_intervals) and all('-' not in iv["label"] for iv in flat_intervals)

    # If this edition carries Storr card milestones, anchor on them and ignore
    # its own <l n> entirely (same treatment the Greek baseline gets).
    has_card_milestones = any(
        e.tag.split("}")[-1] == "milestone" and e.get("unit") == "card"
        for e in text_entry.iter())

    current_book = next(iter(master_intervals))
    cur_label = None
    buffer_map = {}

    def _add_content(bk, label, html):
        if html and html.strip():
            buffer_map.setdefault((bk, label), []).append(html)

    def _find_interval_for_line(bk, line_num):
        if not str(line_num).isdigit(): return None
        ln = int(line_num)
        for iv in flat_intervals:
            if iv["book"] == bk and iv["start_line"] <= ln <= iv["end_line"]: return iv
        for iv in flat_intervals:
            if iv["book"] == bk and iv["start_line"] <= ln: return iv
        # Book-scoped fallback (e.g. an argument line numbered "0", before
        # any card's own start_line): stay within THIS book. The old bare
        # `return flat_intervals[0]` returned the first interval in the
        # WHOLE flattened list across every book (book 1's), silently
        # reassigning current_book to book 1 whenever a book's own bounded
        # lookups found nothing -- which corrupted every book after the
        # first (see the tag != "div" note above for how this surfaced).
        for iv in flat_intervals:
            if iv["book"] == bk: return iv
        return flat_intervals[0] if flat_intervals else None

    def _get_first_line_num(node):
        if node.tag.split("}")[-1] == "l": return node.get("n")
        for ch in node.iter():
            if ch.tag.split("}")[-1] == "l": return ch.get("n")
        return None

    def _walk(elem):
        nonlocal current_book, cur_label
        tag = elem.tag.split("}")[-1]

        # Some editions (e.g. Evelyn-White's 1914 Theogony translation) embed
        # the card milestone AS THE FIRST CHILD of <l> rather than as a
        # preceding sibling (contrast the Greek baseline, which always puts
        # it before <l>). Because <l>/<stage> are leaves below — their full
        # text is pulled in one shot via extract_text_recursive and we never
        # recurse into them with _walk — a milestone nested this way is
        # never otherwise seen, so the card boundary silently never advances
        # and the whole text collapses into the first card. Check for it here.
        if tag in ("l", "stage"):
            for desc in elem.iter():
                if desc is elem:
                    continue
                if desc.tag.split("}")[-1] == "milestone" and desc.get("unit") == "card":
                    n_val = (desc.get("n") or "").strip()
                    if n_val and (current_book, n_val) in card_n_to_label:
                        cur_label = card_n_to_label[(current_book, n_val)]
                    break  # only the leading milestone (if any) should matter

        if tag == "div":
            subtype = (elem.get("subtype") or elem.get("type") or "").lower()
            n_val = (elem.get("n") or "").strip()
            if subtype == "book" and n_val:
                current_book = n_val
                # Kill stale carry-over: without this, cur_label keeps
                # whatever card label the PREVIOUS book last set, and if
                # this new book has any content before its own first card
                # milestone actually lands (a head/argument, a milestone
                # whose @n doesn't match card_n_to_label, etc.) that content
                # -- and sometimes a whole card's worth of it -- gets bucketed
                # under (new book, previous book's last label), producing a
                # phantom duplicate card in the new book's own line list.
                # Same fix already applied to parse_card_prose_tei; ported
                # here after the identical symptom showed up for poetry_cards
                # editions (Mooney/Seaton/Brunck on Apollonius, book N+1
                # inheriting book N's final card).
                _ivs = master_intervals.get(current_book)
                cur_label = _ivs[0]["label"] if _ivs else None
            elif subtype in ("card", "poem") and n_val and (current_book, n_val) in card_n_to_label:
                cur_label = card_n_to_label[(current_book, n_val)]
        elif tag == "milestone" and elem.get("unit") == "card":
            n_val = (elem.get("n") or "").strip()
            if n_val and (current_book, n_val) in card_n_to_label:
                cur_label = card_n_to_label[(current_book, n_val)]
            # else: a milestone whose n is not a master card -> leave cur_label,
            #       its text folds into the current card (and is worth flagging).

        # Line-number fallback ONLY for editions with no milestones at all,
        # and only when cards are genuinely line-ranged (not poem-carded --
        # see is_poem_carded above). Must NOT run on "div" itself: the
        # book-boundary block above already set current_book/cur_label
        # correctly from the div's own @n, but _get_first_line_num on a
        # book <div> recurses into its ENTIRE subtree and returns that
        # book's very first <l> (often an argument line numbered "0",
        # before any card's start_line) -- which matches no interval in
        # THIS book and falls through to _find_interval_for_line's final
        # catch-all, `flat_intervals[0]`, the first interval in the WHOLE
        # flattened list (i.e. book 1's), not this book's. That silently
        # resets current_book to "1" at the top of every OTHER book's
        # subtree, and everything in it gets misfiled into book 1's cards
        # for the rest of that book. Only ever surfaced here because this
        # fallback was previously never exercised: every prior milestone-
        # carded work sets has_card_milestones=True and skips this whole
        # block, so a bookless-argument-line edition (Nonnus) is the first
        # to hit it.
        if not has_card_milestones and not is_poem_carded and tag != "div":
            lh = _get_first_line_num(elem)
            if lh:
                lookup = line_remap.get(str(lh), lh) if line_remap else lh
                iv = _find_interval_for_line(current_book, lookup)
                if iv:
                    cur_label = iv["label"]; current_book = iv["book"]

        label = cur_label
        if not label:
            bk_ivs = master_intervals.get(current_book, [])
            label = bk_ivs[0]["label"] if bk_ivs else "1"

        if tag == "milestone" and elem.get("unit") == "line":
            ln_num = (elem.get("n") or "").strip()
            if ln_num:
                _add_content(current_book, label,
                    f'<span class="inline-line-milestone" title="Line Milestone {ln_num}">{ln_num}</span>')



        if tag in ("l", "stage"):
            _add_content(current_book, label,
                         extract_text_recursive(elem, strip_paragraphs=True, lineno_sigil=lineno_sigil))
            return
        elif tag == "p":
            has_verse_children = any(
                c.tag.split("}")[-1] in ("l", "milestone") for c in elem)
            if has_verse_children:
                if elem.text and elem.text.strip():
                    _add_content(current_book, label, elem.text)
                for ch in elem:
                    _walk(ch)
                if elem.tail:
                    _add_content(current_book, label, elem.tail)
                return
            t = extract_text_recursive(elem, strip_paragraphs=True).strip()
            if t: _add_content(current_book, label, f"<p>{t}</p>")
            return
        elif tag == "note":
            t = extract_text_recursive(elem, strip_paragraphs=True).strip()
            if t:
                # Standalone end-of-poem notes (apparatus criticus etc.) carry
                # an @xml:id like "n1.1.13" (BOOK.POEM.LINE, matching the
                # inline <note target="#n1.1.13"/> anchor back in the verse).
                # Once detached from that anchor down here, the bare note
                # text alone doesn't say which line it's about -- show the
                # id (dropping the leading "n") so it's actually useful.
                note_id = elem.get("{http://www.w3.org/XML/1998/namespace}id") or elem.get("xml:id") or ""
                if note_id.startswith("n"):
                    note_id = note_id[1:]
                id_prefix = f'<b class="note-id">{note_id}</b> ' if note_id else ''
                _add_content(current_book, label, f'<span class="note">[{id_prefix}{t}]</span>')
            return

        if elem.text and elem.text.strip():
            _add_content(current_book, label, elem.text)
        for ch in elem:
            _walk(ch)
        if elem.tail:
            _add_content(current_book, label, elem.tail)

    _walk(text_entry)
    for (bk, label), snips in buffer_map.items():
        combined = " ".join(t.strip() for t in snips if t.strip())
        if combined:
            data.setdefault(bk, OrderedDict())[label] = {"1": combined}
    return data

    """Prose translation/edition with NO <l> tags, segmented only by embedded
    baseline card milestones <milestone unit='card' edRef='Storr' n='S'/> that
    commonly sit INSIDE <p>/<s>. Streams content in document order and bins each
    run into the Storr card named by the most recent card milestone, so output is
    keyed by Storr card label and aligns to the grid. <s> sentences are rendered
    atomically (balanced markup) and a card milestone that opens a sentence
    switches the card before that sentence is binned."""
