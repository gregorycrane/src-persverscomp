"""Build orchestrator -- the `make` entry point. NEW module.

Flow: if the monolith is missing (fresh clone, or cleanup.py ran),
reconstitute it from the deployed shards first (no TEI re-parsing needed).
Then run the normal manifest-driven staleness pass: only works whose
declared source files (or the parser/core code that reads them) actually
changed get re-ingested. Sharding and index.html only get rebuilt if
something changed.
"""
import argparse
import sqlite3
from pathlib import Path

from pipeline.config import DB_PATH, WORKSPACE_DIR
from pipeline.registry import WORK_REGISTRY, WORK_REGISTRY_PATH
from pipeline.manifest import load_manifest, save_manifest, is_stale, record
from pipeline.parsers import DOC_TYPE_PARSERS
from pipeline.ingest_work import ingest_works
from pipeline.core.storage import init_storage_engine
from pipeline.reconstitute import reconstitute_monolith
from pipeline import sharding, index_builder

_CORE_DIR = Path(__file__).parent / "core"
_CORE_FILES = [_CORE_DIR / "xml_utils.py", _CORE_DIR / "storage.py",
               _CORE_DIR / "canonical_intervals.py", _CORE_DIR / "alignment.py"]


def dep_paths_for(work_key: str, meta: dict) -> list:
    """Every file whose change should invalidate this work's manifest
    fingerprint: its own declared source files, the specific parser module
    it dispatches to (if any), the shared core modules, and the registry
    itself (a hand-edited path/config fix should also trigger a rebuild).
    """
    paths = [WORK_REGISTRY_PATH, *_CORE_FILES]
    for group in ("editions", "appcrits", "translations", "commentaries"):
        for entry in meta.get(group, {}).values():
            if "path" in entry:
                paths.append(Path(entry["path"]))
    for tb in meta.get("treebanks", {}).values():
        if "path" in tb:
            paths.append(Path(tb["path"]))
    for aln in meta.get("alignments", {}).values():
        if "path" in aln:
            paths.append(Path(aln["path"]))
    for tsv in meta.get("edition_alignments", []):
        paths.append(Path(tsv))
    if meta.get("speakers_csv"):
        paths.append(Path(meta["speakers_csv"]))
    doc_type = meta.get("doc_type")
    parser_fn = DOC_TYPE_PARSERS.get(doc_type)
    if parser_fn is not None:
        paths.append(Path(parser_fn.__globals__["__file__"]))
    return paths


def main(argv=None):
    ap = argparse.ArgumentParser(description="Perseus Multitext Viewer build orchestrator")
    ap.add_argument("--work", action="append", dest="works",
                     help="only build this work_key (repeatable)")
    ap.add_argument("--force", action="store_true",
                     help="ignore the manifest, rebuild every targeted work")
    ap.add_argument("--skip-index", action="store_true",
                     help="rebuild shards but don't regenerate index.html")
    args = ap.parse_args(argv)

    if not DB_PATH.exists():
        shard_root = WORKSPACE_DIR / "site" / "data"
        if shard_root.exists() and any(shard_root.rglob("*.db")):
            reconstitute_monolith(DB_PATH, shard_root).close()
        else:
            print(f"[monolith] not present and no shards found under {shard_root} "
                  f"-- initializing an empty monolith (every work is stale).")
            init_storage_engine(DB_PATH).close()

    manifest = {} if args.force else load_manifest()
    target_keys = args.works or list(WORK_REGISTRY.keys())

    conn = sqlite3.connect(str(DB_PATH))
    changed = []
    for work_key in target_keys:
        meta = WORK_REGISTRY[work_key]
        deps = dep_paths_for(work_key, meta)
        if args.force or is_stale(work_key, deps, manifest):
            print(f"[build] {work_key} -- stale, ingesting")
            ingest_works(conn, work_keys=[work_key])
            record(work_key, deps, manifest)
            changed.append(work_key)
        else:
            print(f"[skip]  {work_key} -- unchanged")
    conn.close()

    if changed:
        sharding.split_corpus_by_work(str(DB_PATH), str(WORKSPACE_DIR / "site"))
        if not args.skip_index:
            conn = sqlite3.connect(str(DB_PATH))
            index_builder.rebuild(conn)
            conn.close()

    save_manifest(manifest)
    print(f"\n{len(changed)}/{len(target_keys)} work(s) rebuilt.")


if __name__ == "__main__":
    main()
