"""Shared XML/TEI helpers used by every parser. Relocated from Cell 4."""
import re
import xml.etree.ElementTree as ET
from pipeline.config import NS, _LXML
try:
    import lxml.etree as LET
except ImportError:
    pass

def _ns(work_key):
    """Derive the CTS namespace from the textgroup prefix, e.g. tlg0012 → greekLit.
    Extend TEXTGROUP_NAMESPACE for other collections (stoa, etc.)."""
    _tg = work_key.split(".")[0]
    _m = re.match(r"[A-Za-z]+", _tg)
    _val = TEXTGROUP_NAMESPACE.get(_m.group(0).lower() if _m else "")
    if _val is None:
        print(f"  \u26a0 unknown textgroup prefix in '{work_key}'; defaulting to greekLit")
        _val = "greekLit"
    return _val

def safe_parse(path):
    if _LXML:
        parser = LET.XMLParser(recover=True)
        tree = LET.parse(path, parser=parser)
        import io
        buf = io.BytesIO()
        tree.write(buf)
        buf.seek(0)
        return ET.parse(buf)
    return ET.parse(path)

def find_text_root(root):
    # Only treat a translation/commentary div as THE text root when it's a
    # direct child of <body> -- i.e. the whole document genuinely IS a
    # translation or commentary edition. Previously this scanned the ENTIRE
    # tree in document order and returned the first type="translation"/
    # "commentary" div found anywhere -- which, for critical editions like
    # Wilamowitz that embed small <div type="commentary"> wrappers around
    # individual scholia/testimonia quotes deep inside the apparatus, meant
    # find_text_root latched onto a three-line scholion instead of the whole
    # play (zero <l>, zero milestones under it), so every card silently had
    # no content to bin and the client showed "Not divided separately in
    # this edition" almost everywhere. Restricting the scan to body's direct
    # children fixes that while still handling genuine whole-document
    # translation/commentary editions correctly.
    body = root.find('.//{http://www.tei-c.org/ns/1.0}body')
    if body is None:
        body = root.find('.//body')
    if body is not None:
        for div in body:
            tag = div.tag.split('}')[-1]
            if tag != 'div':
                continue
            if div.get('type') in ('translation', 'commentary'):
                return div
        return body
    return root.find('.//{http://www.tei-c.org/ns/1.0}body') or root.find('.//body') or root.find('.//*body')

def extract_text_recursive(elem, strip_paragraphs=False, lineno_sigil=None, _nested=False):
    # _nested: True whenever this call is reached by recursing INTO a
    # parent element's children (see the `for child in elem` loop and the
    # note-handling branch below), as opposed to being the original,
    # direct call a caller makes on an <l> element it already knows is
    # one of the work's own numbered verse lines. Every genuine top-level
    # verse-line call site in this notebook calls extract_text_recursive(l, ...)
    # directly on the <l> itself, so it naturally gets _nested's default of
    # False; an <l> only reached via recursion is, by construction, a
    # quotation embedded inside something else (a note, a lemma, a <quote>)
    # -- see the tag == 'l' handling below for why that distinction matters.
    # (NOTE: this replaces an earlier version of this fix that keyed off
    # strip_paragraphs=True instead -- wrong, because the genuine top-level
    # verse-line call sites ALSO pass strip_paragraphs=True, so that version
    # suppressed the line-num-cell/line-text-cell grid for real verse lines
    # too, breaking the Focus column's own line numbers and the alignment
    # grid that depends on them.)
    parts = []
    tag = elem.tag.split('}')[-1]
    
    if tag == 'l':
        # An <l> reached via recursion (_nested=True) is a quotation of
        # verse embedded INSIDE prose -- e.g. Mooney's commentary notes
        # quoting Homer or Catullus for comparison -- not the work's own
        # numbered text. The line-num-cell/line-text-cell pair below is the
        # marker the FRONT END uses to detect "this column is a real verse
        # edition, wrap it in the 2-column poetry grid". Emitting that same
        # marker for a quoted line buried inside an ordinary comm-note span
        # made a commentary card that merely quoted one line of verse
        # anywhere in its notes look exactly like a genuine verse column to
        # that check, so the whole card got wrapped in the 45px/1fr poetry
        # grid and its ordinary comm-lineno/comm-entry blocks were
        # auto-placed alternately into the narrow and wide tracks -- the
        # 'squeezed into a tiny column' look, regardless of the actual
        # column width. A quoted line just needs its own line break (see
        # the matching close below), not a grid cell.
        if not _nested:
            line_num = (elem.get('n') or '').strip()
            if line_num:
                if lineno_sigil:
                    parts.append(f'<div class="line-num-cell" data-n="{line_num}">'
                                 f'<span class="src-lineno">[{line_num} {lineno_sigil}]</span></div>')
                else:
                    parts.append(f'<div class="line-num-cell">{line_num}</div>')
            else:
                parts.append('<div class="line-num-cell\">&nbsp;</div>')
            parts.append('<div class="line-text-cell">')
    
    elif tag == 'sic':
        parts.append('<span class="tei-sic">[')
    elif tag == 'corr':
        parts.append(' <span class="tei-corr">')
    elif tag == 'speaker': 
        parts.append('<strong class="speaker-attr">')
    elif tag == 'stage':
        parts.append('<div class=\"stage-direction\">')
    elif tag == 'hi':
        rend = elem.get('rend', 'italic')
        parts.append(f'<span class="render-{rend}">')
    elif tag == 's':
        parts.append('<span class="lemma">')
    elif tag == 'del':
        parts.append('<span class="tei-del">[')
    elif tag == 'add':
        parts.append('<span class="tei-add">\u27e8')   # ⟨
    elif tag == 'quote':
        q_type = elem.get('type', 'blockquote')
        parts.append(f'<div class="quote-block type-{q_type}">')
    elif tag == 'p' and not strip_paragraphs:
        parts.append('<div class="prose-para">')
    elif tag == 'milestone' and elem.get('unit') == 'line':
        ln_num = (elem.get('n') or '').strip()
        if ln_num:
            parts.append(f'<span class="inline-line-milestone" title="Line Milestone {ln_num}">{ln_num}</span>')
    elif tag == 'milestone' and elem.get('unit') == 'page':
        pg = (elem.get('n') or '').strip()
        resp = (elem.get('resp') or '').strip()
        if pg:
            tip = (resp + ' ' + pg).strip()
            parts.append(f'<span class="milestone bekker-page" data-resp="{resp}" title="{tip}">{pg}</span>')
    elif tag == 'q':
        parts.append('\u201c')
    elif tag == 'foreign':
        lang = (elem.get('{http://www.w3.org/XML/1998/namespace}lang') or '').strip()
        cls  = f'foreign foreign-{lang}' if lang else 'foreign'
        parts.append(f'<span class="{cls}" lang="{lang}">')
    elif tag == 'seg' and elem.get('type') == 'metrical-part':
        part_n = elem.get('n', '')
        parts.append(f'<span class="metrical-part metrical-part-{part_n}">')
    elif tag == 'seg':
        rend = (elem.get('rend') or '').strip()
        parts.append(f'<span class="seg seg-{rend}">' if rend else '<span class="seg">')
    if elem.text: 
        parts.append(elem.text)
        
    for child in elem:
        child_tag = child.tag.split('}')[-1]
        if child_tag == 'note':
            note_text = extract_text_recursive(child, strip_paragraphs, _nested=True).strip()
            if note_text: parts.append(f'<span class="note">[{note_text}]</span>')
        elif child_tag == 'lb':
            # <lb/> marks a physical line break in the PRINTED PAGE layout
            # (these commentary/apparatus files were transcribed line-for-line
            # off a narrow printed column), not a semantic break. Rendering it
            # as a hard <br/> forced every prose/commentary note to wrap at the
            # *original* page's line width instead of reflowing to fill the
            # reading pane -- that's what produced the 'squeezed into a tiny
            # column' look (e.g. Mooney's Apollonius commentary), regardless of
            # how wide the CSS column actually was. Treat it as a soft join
            # (a space) so text reflows normally; verse <l> lines still get
            # their own line-num-cell/line-text-cell grid above and are
            # unaffected by this.
            if parts and not parts[-1].endswith((' ', chr(10))):
                parts.append(' ')
        else: 
            parts.append(extract_text_recursive(child, strip_paragraphs, _nested=True))
        # Tail text after a block-level child must go in its own div,
        # not raw text, to avoid invalid HTML and browser reflow bugs.
        if child.tail and child.tail.strip():
            if child_tag in ('quote', 'stage'):
                parts.append(f'<div class="prose-continuation">{child.tail}</div>')
            else:
                parts.append(child.tail)
        elif child.tail:
            parts.append(child.tail)
            
    if tag == 'l':
        # Matches the open above: a genuine top-level verse line closes its
        # line-text-cell div; a quoted line inside prose just gets a real
        # line break so multi-line quotations still read as separate lines,
        # without the grid markup that trips the front end's poetry-grid
        # detection for the whole surrounding column.
        parts.append('</div>' if not _nested else '<br/>')
    elif tag == 'sic': parts.append(']</span>')
    elif tag == 'corr': parts.append('</span>')
    elif tag == 'speaker': parts.append(': </strong>')
    elif tag == 'stage': parts.append('</div>')
    elif tag == 'hi': parts.append('</span>')
    elif tag == 's': parts.append('</span>')
    elif tag == 'del': parts.append(']</span>')
    elif tag == 'add': parts.append('\u27e9</span>')
    elif tag == 'quote': 
        parts.append('</div>')
    elif tag == 'p' and not strip_paragraphs: parts.append('</div>')
    elif tag == 'q':
        parts.append('\u201d')
    elif tag == 'foreign':
        parts.append('</span>')
    elif tag == 'seg' and elem.get('type') == 'metrical-part':
        parts.append('</span>')
    elif tag == 'seg':
        parts.append('</span>')        
    return ''.join(parts)
